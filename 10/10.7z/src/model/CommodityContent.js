const initState = {
    store: [],
    sum: 0,
    price:0,
    installments:0
};

export default {
    namespace: 'commodityContent',
    state: initState,
    subscriptions: {},
    effects: {

    },
    reducers: {
        //刷新页面数据初始化
        localCarContent(state,{payload}){
                state=payload;
                return {...state};
        },
        // 结算清空购物车
        carClear(state){
            state.store =[];
            state.sum=0;
            state.price=0;
            state.installments=0;
            return {...state}
        },
        //清除购物车单项
        carDelectItem(state,{payload}){
            state.store.map((item,index)=>{
                if(item.id === payload.id){
                    state.store.splice(index,index+1);
                    state.sum= state.sum-payload.sum;
                    state.price= state.price-payload.price*payload.sum;
                    if( item.installments === state.installments ){
                        state.installments =0;
                    }
                }
            })
            return {...state}
        },
        //购物车分期信息
        carInstallment(state){
                state.store.map((item)=>{
                    state.installments =item.installments > state.installments?item.installments :state.installments
                })
                return {...state}
        },
        //购物车价格总计
        carPrice(state, {payload}){
            state.price=payload.price+state.price;
            return {...state}
        },
        //购车内容添加操作
        carContent(state, {payload}) {
            if (state.store.length === 0) {
                payload.sum= 1;
                state.store.push(payload);
                state.sum = state.sum + 1;  
            } else {
                let bool = false;
                for (let v of state.store) {
                    if (v.id === payload.id) {
                    state.sum = state.sum + 1;
                        v.sum++
                     
                        bool = true;
                        break
                    }
                }
                if (!bool) {
                    state.sum = state.sum + 1;
                    payload.sum = 1;
                    state.store.push(payload);
                }
            }
            let value ={...state}
            window.localStorage.setItem("value", JSON.stringify(value));

            return {
                ...state
            }
        },
        //总计件数减操作
        carReduction(state,{payload}){
            state.store.map((item)=>{
                if(item.id === payload && item.sum>0 && state.sum>0){
                    item.sum= item.sum-1;
                    state.sum =state.sum-1;
                }
                
            })
            
            return {...state}
        },
        //购物车价格总计减操作
        carPriceReduction(state,{payload}){
            state.price=state.price-payload.price;
            return {...state}
        },
        //购物车价格总计加操作
        carAddPrice(state,{payload}){
            state.price =state.price+payload.price;
            payload.sum=payload.sum+1;
            state.sum =state.sum+1;
         return {...state}
        }
       
    }
}