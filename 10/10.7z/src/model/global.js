const initState = {text:'我是全局的state'};

export default {
    namespace:'global',
    state:initState,
    subscriptions:{},
    effects:{},
    reducers:{}
}