const initState = {



};

export default {
    namespace:'CommodityContent',
    state:initState,
    subscriptions:{},
    effects:{},
    reducers:{}
}