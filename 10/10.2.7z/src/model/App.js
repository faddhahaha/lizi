const initState = {

};

export default {
    namespace:'App',
    state:initState,
    subscriptions:{},
    effects:{

    },
    reducers:{
        
    }
}